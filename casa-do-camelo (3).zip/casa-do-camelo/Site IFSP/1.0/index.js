const express = require('express');
const path = require('path');
const mysql67 = require('mysql2');

const app = express();

// Lê o JSON que o formulário manda
app.use(express.json());

// Serve os arquivos da pasta 'site' (HTML, CSS, JS, imagens)
app.use(express.static(path.join(__dirname, 'site')));

// Pool de conexões (reconecta sozinho se o MySQL derrubar a conexão parada)
// .promise() deixa a gente usar async/await em vez de callbacks
const db = mysql67.createPool({
    host: 'localhost',
    user: 'root',
    password: 'ifsp',
    database: 'casa_do_camelo'
}).promise();

// A tabela Nome_Game guarda os jogos, mas com nomes de colunas diferentes dos
// que o site usa. O "AS" traduz: o front-end continua recebendo
// { id, titulo, tipo, plataforma, imagem, descricao, link }
const CAMPOS = `
    id_game    AS id,
    nome       AS titulo,
    tipo,
    plataforma,
    imagem_url AS imagem,
    descricao,
    link
`;

// O site precisa de 3 colunas que o banco_atualizado.sql não tem na Nome_Game.
// Na primeira vez que o servidor sobe, elas são criadas. Nas próximas,
// o MySQL avisa que já existem (erro 1060) e a gente ignora.
async function garantirColunas() {
    const colunas = [
        "tipo VARCHAR(20) NOT NULL DEFAULT 'Repack'",
        'plataforma VARCHAR(100) NULL',
        'link VARCHAR(500) NULL'
    ];

    for (const coluna of colunas) {
        try {
            await db.query(`ALTER TABLE Nome_Game ADD COLUMN ${coluna}`);
            console.log('coluna criada em Nome_Game:', coluna.split(' ')[0]);
        } catch (erro) {
            if (erro.code !== 'ER_DUP_FIELDNAME') throw erro;
        }
    }
}

// Pega só os campos que interessam (evita salvar lixo)
function limpar(dados) {
    return {
        titulo: String(dados.titulo || '').trim(),
        tipo: String(dados.tipo || 'Repack'),
        plataforma: String(dados.plataforma || '').trim(),
        imagem: String(dados.imagem || '').trim(),
        descricao: String(dados.descricao || '').trim(),
        link: String(dados.link || '').trim()
    };
}

// Busca um jogo pelo id (devolve undefined se não existir)
async function buscarPorId(id) {
    const [linhas] = await db.query(`SELECT ${CAMPOS} FROM Nome_Game WHERE id_game = ?`, [id]);
    return linhas[0];
}

// Os ids vêm da URL como texto; aqui garantimos que é um número inteiro
function lerId(req) {
    const id = Number(req.params.id);
    return Number.isInteger(id) && id > 0 ? id : null;
}

// LISTAR todos
app.get('/api/jogos', async (req, res) => {
    try {
        const [jogos] = await db.query(`SELECT ${CAMPOS} FROM Nome_Game ORDER BY id_game`);
        res.json(jogos);
    } catch (erro) {
        console.error('erro ao listar jogos:', erro);
        res.status(500).json({ erro: 'erro ao buscar dados' });
    }
});

// PEGAR um pelo id
app.get('/api/jogos/:id', async (req, res) => {
    const id = lerId(req);
    if (!id) return res.status(400).json({ erro: 'Id inválido' });

    try {
        const jogo = await buscarPorId(id);
        if (!jogo) return res.status(404).json({ erro: 'Jogo não encontrado' });
        res.json(jogo);
    } catch (erro) {
        console.error('erro ao buscar jogo:', erro);
        res.status(500).json({ erro: 'erro ao buscar dados' });
    }
});

// CRIAR
app.post('/api/jogos', async (req, res) => {
    const jogo = limpar(req.body);
    if (!jogo.titulo) return res.status(400).json({ erro: 'Título é obrigatório' });

    const sql67 = `INSERT INTO Nome_Game (nome, tipo, plataforma, imagem_url, descricao, link)
                   VALUES (?, ?, ?, ?, ?, ?)`;
    const valores = [jogo.titulo, jogo.tipo, jogo.plataforma, jogo.imagem, jogo.descricao, jogo.link];

    try {
        const [resultado] = await db.query(sql67, valores);
        console.log('obra cadastrada, ID:', resultado.insertId);
        res.status(201).json({ id: resultado.insertId, ...jogo });
    } catch (erro) {
        console.error('erro ao inserir no MySQL:', erro);
        res.status(500).json({ erro: 'erro ao salvar no banco' });
    }
});

// EDITAR
app.put('/api/jogos/:id', async (req, res) => {
    const id = lerId(req);
    if (!id) return res.status(400).json({ erro: 'Id inválido' });

    const jogo = limpar(req.body);
    if (!jogo.titulo) return res.status(400).json({ erro: 'Título é obrigatório' });

    const sql67 = `UPDATE Nome_Game
                   SET nome = ?, tipo = ?, plataforma = ?, imagem_url = ?, descricao = ?, link = ?
                   WHERE id_game = ?`;
    const valores = [jogo.titulo, jogo.tipo, jogo.plataforma, jogo.imagem, jogo.descricao, jogo.link, id];

    try {
        await db.query(sql67, valores);
        // Busca de novo: assim também descobrimos se o id existe
        const atualizado = await buscarPorId(id);
        if (!atualizado) return res.status(404).json({ erro: 'Jogo não encontrado' });
        res.json(atualizado);
    } catch (erro) {
        console.error('erro ao atualizar no MySQL:', erro);
        res.status(500).json({ erro: 'erro ao salvar no banco' });
    }
});

// EXCLUIR
app.delete('/api/jogos/:id', async (req, res) => {
    const id = lerId(req);
    if (!id) return res.status(400).json({ erro: 'Id inválido' });

    try {
        const [resultado] = await db.query('DELETE FROM Nome_Game WHERE id_game = ?', [id]);
        if (resultado.affectedRows === 0) return res.status(404).json({ erro: 'Jogo não encontrado' });
        res.json({ status: 'excluido' });
    } catch (erro) {
        console.error('erro ao excluir no MySQL:', erro);
        res.status(500).json({ erro: 'erro ao excluir' });
    }
});

// Qualquer outra rota /api/... responde JSON (nunca HTML). Foi a página HTML de
// erro do Express que causava o "JSON.parse: unexpected character" no navegador.
app.use('/api', (req, res) => {
    res.status(404).json({ erro: 'Rota não encontrada' });
});

app.use((erro, req, res, next) => {
    console.error('erro inesperado:', erro);
    res.status(500).json({ erro: 'erro interno do servidor' });
});

garantirColunas()
    .then(() => console.log('conectado ao banco!'))
    .catch(erro => console.error(':( não consegui preparar o banco:', erro.message))
    .finally(() => {
        app.listen(3000, () => {
            console.log('Servidor rodando em http://localhost:3000');
        });
    });
