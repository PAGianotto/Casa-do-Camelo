# Casa do Camelo

Site de repacks, mods, ROMs e romhacks em português.

## Como rodar
1. `npm install` (só na primeira vez)
2. `node index.js`
3. Abra http://localhost:3000

## Arquivos
| Arquivo | O que faz |
|---|---|
| `index.js` | Servidor Express + API (`/api/jogos`: listar, ver um, criar, editar, excluir) |
| `site/index.html` | Home: lista os cards com filtro por tipo |
| `site/form.html` | Formulário: cria um card (`form.html`) ou edita (`form.html?id=3`), com prévia ao vivo |
| `site/card.html` | Página de um jogo (`card.html?id=3`) com banner e botão de baixar |
| `site/style.css` | Todo o visual (um CSS só) |
| `site/scriptindex.js` | `criarCard()` + código da home e da página do card |
| `site/scriptForm.js` | Código do formulário (prévia, salvar, excluir) |

Obs.: os dados ficam na memória do servidor, então reiniciar o `node` volta aos exemplos.
