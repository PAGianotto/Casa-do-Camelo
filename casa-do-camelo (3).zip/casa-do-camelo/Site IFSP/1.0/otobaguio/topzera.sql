show databases;
use casa_do_camelo;
select * from genre;
insert into genre (nome) values ('Plataforma'), ('Sandbox'), ('open_world');