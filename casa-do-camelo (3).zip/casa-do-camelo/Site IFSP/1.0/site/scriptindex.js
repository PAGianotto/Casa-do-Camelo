// ===== Funções usadas por todas as páginas =====

// Impede que alguém quebre o site digitando HTML no formulário
function escapar(texto) {
    const div = document.createElement('div');
    div.textContent = texto ?? '';
    return div.innerHTML;
}

// Monta o HTML de UM card de jogo.
// É usada na home e também na prévia do formulário.
function criarCard(jogo) {
    const imagem = jogo.imagem
        ? `<img class="card-img" src="${escapar(jogo.imagem)}" alt="${escapar(jogo.titulo)}"
                onerror="this.outerHTML='<div class=&quot;card-img card-sem-img&quot;>🎮</div>'">`
        : `<div class="card-img card-sem-img">🎮</div>`;

    // Na prévia o jogo ainda não tem id, então não mostra os botões
    const acoes = jogo.id
        ? `<div class="card-acoes">
               <a class="btn" href="card.html?id=${jogo.id}">Ver mais</a>
               <a class="btn btn-secundario" href="form.html?id=${jogo.id}">Editar</a>
           </div>`
        : '';

    const titulo = jogo.id
        ? `<a href="card.html?id=${jogo.id}">${escapar(jogo.titulo)}</a>`
        : escapar(jogo.titulo || 'Nome do jogo');

    return `
        <article class="card">
            ${imagem}
            <div class="card-info">
                <h3 class="card-titulo">${titulo}</h3>
                <div class="tags">
                    <span class="tag tag-tipo">${escapar(jogo.tipo)}</span>
                    ${jogo.plataforma ? `<span class="tag">${escapar(jogo.plataforma)}</span>` : ''}
                </div>
                <p class="card-descricao">${escapar(jogo.descricao || 'Sem descrição.')}</p>
                ${acoes}
            </div>
        </article>
    `;
}

// ===== Home (index.html) =====
const container = document.getElementById('todosCards');

if (container) {
    let todosJogos = [];

    function mostrarCards(filtro) {
        const lista = filtro === 'Todos'
            ? todosJogos
            : todosJogos.filter(j => j.tipo === filtro);

        container.innerHTML = lista.length
            ? lista.map(criarCard).join('')
            : '<p class="vazio">Nada por aqui ainda. <a href="form.html">Cadastre o primeiro!</a></p>';
    }

    fetch('/api/jogos')
        .then(resposta => {
            if (!resposta.ok) throw new Error('Servidor respondeu ' + resposta.status);
            return resposta.json();
        })
        .then(dados => {
            todosJogos = dados;
            mostrarCards('Todos');
        })
        .catch(erro => {
            console.error('Erro ao buscar os jogos:', erro);
            container.innerHTML = '<p class="vazio">Não deu pra carregar. O servidor (node index.js) está rodando?</p>';
        });

    // Botões de filtro
    document.querySelectorAll('#filtros button').forEach(botao => {
        botao.addEventListener('click', () => {
            document.querySelectorAll('#filtros button').forEach(b => b.classList.remove('ativo'));
            botao.classList.add('ativo');
            mostrarCards(botao.dataset.tipo);
        });
    });
}

// ===== Página de detalhe (card.html) =====
const detalhe = document.getElementById('detalhe');

if (detalhe) {
    const id = new URLSearchParams(location.search).get('id');

    fetch('/api/jogos/' + id)
        .then(resposta => {
            if (!resposta.ok) throw new Error('não encontrado');
            return resposta.json();
        })
        .then(jogo => {
            document.title = jogo.titulo + ' - Casa do Camelo';
            if (jogo.imagem) {
                document.getElementById('banner').style.backgroundImage = `url("${jogo.imagem.replace(/"/g, '')}")`;
            }
            detalhe.innerHTML = `
                <h1>${escapar(jogo.titulo)}</h1>
                <div class="tags">
                    <span class="tag tag-tipo">${escapar(jogo.tipo)}</span>
                    ${jogo.plataforma ? `<span class="tag">${escapar(jogo.plataforma)}</span>` : ''}
                </div>
                <p>${escapar(jogo.descricao || 'Sem descrição.')}</p>
                <div class="form-botoes">
                    ${/^https?:\/\//.test(jogo.link) ? `<a class="btn" href="${escapar(jogo.link)}" target="_blank" rel="noopener">⬇ Baixar</a>` : ''}
                    <a class="btn btn-secundario" href="form.html?id=${jogo.id}">Editar</a>
                    <a class="btn btn-secundario" href="index.html">Voltar</a>
                </div>
            `;
        })
        .catch(() => {
            detalhe.innerHTML = '<h1>Jogo não encontrado</h1><a class="btn" href="index.html">Voltar</a>';
        });
}
