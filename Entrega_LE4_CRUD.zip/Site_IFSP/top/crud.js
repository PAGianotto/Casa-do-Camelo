// =====================================================================
// crud.js  -  O "motor" que transforma a planta (entidades.js) em tela.
//
// CRUD = Create (criar), Read (ler/listar), Update (editar), Delete (excluir)
// Os dados ficam no localStorage do navegador (igual ao script.js original do grupo).
// Cada entidade vira uma "tabela" guardada com o nome  db_<entidade>.
// =====================================================================

// Qual tela estou? O <body> de cada página diz: <body data-entidade="game">
const nomeEnt = document.body.dataset.entidade;
const ent = ENTIDADES[nomeEnt];

// ---------- Funções de "banco de dados" (localStorage) ----------
// ler(tabela)  -> devolve a lista de registros daquela tabela
function ler(tabela) {
    try { return JSON.parse(localStorage.getItem('db_' + tabela)) || []; }
    catch (e) { return []; }
}
// gravar(tabela, lista) -> salva a lista inteira (localStorage só guarda texto, por isso JSON.stringify)
function gravar(tabela, lista) {
    localStorage.setItem('db_' + tabela, JSON.stringify(lista));
}

// ---------- Utilidades ----------
// esc(): evita que um texto digitado vire código HTML (segurança básica contra <script>)
function esc(t) {
    return String(t ?? '').replace(/[&<>"']/g, c =>
        ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
// rotulo(): dado o id de um registro, devolve o texto bonito dele (ex.: id 3 -> "Nintendo")
function rotulo(tabela, id) {
    const reg = ler(tabela).find(r => r.id === id);
    if (!reg) return '';
    return reg[ENTIDADES[tabela].exibir || 'nome'] ?? ('#' + id);
}

// ---------- Elementos da página ----------
const form   = document.getElementById('form');
const tabela = document.getElementById('tabela');
const titulo = document.getElementById('titulo');
const menu   = document.getElementById('menu');
const msg    = document.getElementById('msg');
let editandoId = null;   // null = criando novo | número = editando aquele registro

titulo.textContent = 'Cadastro de ' + ent.titulo;
document.title = 'Cadastro de ' + ent.titulo;

// Menu com link para todas as telas
menu.innerHTML = Object.keys(ENTIDADES).map(k =>
    `<a href="cadastro_${k}.html" class="${k === nomeEnt ? 'ativo' : ''}">${ENTIDADES[k].titulo}</a>`
).join('');

// ---------- Monta o formulário a partir dos campos ----------
function montarFormulario() {
    let html = '';
    ent.campos.forEach(c => {
        const req = c.obrigatorio ? 'required' : '';
        html += `<label for="${c.nome}">${c.rotulo}${c.obrigatorio ? ' *' : ''}</label>`;

        if (c.tipo === 'textarea') {
            html += `<textarea id="${c.nome}" rows="3" ${req}></textarea>`;

        } else if (c.tipo === 'select' || c.tipo === 'multi') {
            const opcoes = ler(c.ref);
            const multiplo = c.tipo === 'multi' ? 'multiple size="4"' : '';
            html += `<select id="${c.nome}" ${multiplo} ${req}>`;
            if (c.tipo === 'select') html += `<option value="">-- escolha --</option>`;
            html += opcoes.map(o => `<option value="${o.id}">${esc(rotulo(c.ref, o.id))}</option>`).join('');
            html += `</select>`;
            if (opcoes.length === 0)
                html += `<small>Cadastre primeiro em <a href="cadastro_${c.ref}.html">${ENTIDADES[c.ref].titulo}</a>.</small>`;

        } else {
            // text, url, number, date
            html += `<input type="${c.tipo}" id="${c.nome}" placeholder="${esc(c.dica || '')}" ${req}
                      ${c.max ? `maxlength="${c.max}"` : ''}>`;
        }
    });
    html += `<div class="botoes">
               <button type="submit" id="btnSalvar">Salvar</button>
               <button type="button" id="btnCancelar" hidden>Cancelar edição</button>
             </div>`;
    form.innerHTML = html;
    document.getElementById('btnCancelar').addEventListener('click', limparFormulario);
}

// Lê o que o usuário digitou e devolve um objeto { nome: '...', pais: '...', ... }
function lerFormulario() {
    const dados = {};
    ent.campos.forEach(c => {
        const el = document.getElementById(c.nome);
        if (c.tipo === 'multi') {
            dados[c.nome] = [...el.selectedOptions].map(o => Number(o.value));
        } else if (c.tipo === 'select') {
            dados[c.nome] = el.value === '' ? null : Number(el.value);
        } else if (c.tipo === 'number') {
            dados[c.nome] = el.value === '' ? null : Number(el.value);
        } else {
            dados[c.nome] = el.value.trim();
        }
    });
    return dados;
}

// Devolve o formulário ao estado "novo cadastro"
function limparFormulario() {
    editandoId = null;
    form.reset();
    document.getElementById('btnSalvar').textContent = 'Salvar';
    document.getElementById('btnCancelar').hidden = true;
}

// ---------- C (Create) e U (Update): salvar ----------
form.addEventListener('submit', function (evento) {
    evento.preventDefault();                  // não deixa a página recarregar
    const dados = lerFormulario();
    const lista = ler(nomeEnt);

    if (editandoId === null) {
        // CREATE: novo id = maior id existente + 1 (imita o AUTO_INCREMENT do MySQL)
        const novoId = lista.reduce((m, r) => Math.max(m, r.id), 0) + 1;
        lista.push({ id: novoId, ...dados });
        mostrar('Registro criado!');
    } else {
        // UPDATE: troca os dados do registro que estava sendo editado
        const i = lista.findIndex(r => r.id === editandoId);
        lista[i] = { id: editandoId, ...dados };
        mostrar('Registro atualizado!');
    }
    gravar(nomeEnt, lista);
    limparFormulario();
    desenharTabela();
});

// ---------- R (Read): listar ----------
function valorDaCelula(c, reg) {
    const v = reg[c.nome];
    if (c.tipo === 'select') return esc(rotulo(c.ref, v)) || '—';
    if (c.tipo === 'multi')  return esc((v || []).map(id => rotulo(c.ref, id)).filter(Boolean).join(', ')) || '—';
    if (v === null || v === undefined || v === '') return '—';
    if (c.tipo === 'url') return `<a href="${esc(v)}" target="_blank" rel="noopener">link</a>`;
    return esc(v);
}

function desenharTabela() {
    const lista = ler(nomeEnt);
    const colunas = ent.campos.filter(c => c.tipo !== 'textarea');
    let html = '<thead><tr><th>ID</th>' + colunas.map(c => `<th>${esc(c.rotulo.split(' (')[0])}</th>`).join('') + '<th>Ações</th></tr></thead><tbody>';

    if (lista.length === 0) {
        html += `<tr><td colspan="${colunas.length + 2}">Nenhum registro ainda.</td></tr>`;
    }
    lista.forEach(reg => {
        html += `<tr><td>${reg.id}</td>` +
            colunas.map(c => `<td>${valorDaCelula(c, reg)}</td>`).join('') +
            `<td><button data-acao="editar" data-id="${reg.id}">Editar</button>
                 <button data-acao="excluir" data-id="${reg.id}" class="perigo">Excluir</button></td></tr>`;
    });
    tabela.innerHTML = html + '</tbody>';
}

// Um único "ouvinte" para todos os botões Editar/Excluir da tabela
tabela.addEventListener('click', function (e) {
    const botao = e.target.closest('button[data-acao]');
    if (!botao) return;
    const id = Number(botao.dataset.id);
    if (botao.dataset.acao === 'editar')  editar(id);
    if (botao.dataset.acao === 'excluir') {
        if (confirm('Excluir este registro (e o que depende dele)?')) {
            excluir(nomeEnt, id);
            desenharTabela();
            mostrar('Registro excluído.');
        }
    }
});

// ---------- U (Update): joga os dados do registro de volta no formulário ----------
function editar(id) {
    const reg = ler(nomeEnt).find(r => r.id === id);
    editandoId = id;
    ent.campos.forEach(c => {
        const el = document.getElementById(c.nome);
        if (c.tipo === 'multi') {
            [...el.options].forEach(o => o.selected = (reg[c.nome] || []).includes(Number(o.value)));
        } else {
            el.value = reg[c.nome] ?? '';
        }
    });
    document.getElementById('btnSalvar').textContent = 'Atualizar';
    document.getElementById('btnCancelar').hidden = false;
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ---------- D (Delete): excluir imitando ON DELETE CASCADE / SET NULL do SQL ----------
// Se apago uma Publicadora, o que aponta para ela precisa ser tratado:
//   - se a ligação é OBRIGATÓRIA (ex.: Arquivo precisa de um Jogo) -> apaga também (CASCADE)
//   - se é opcional (ex.: Jogo -> Publicadora)                      -> fica vazio (SET NULL)
//   - se é N:M (lista de ids)                                       -> só tira o id da lista
function excluir(tabelaAlvo, id) {
    gravar(tabelaAlvo, ler(tabelaAlvo).filter(r => r.id !== id));

    for (const [outraTabela, cfg] of Object.entries(ENTIDADES)) {
        for (const c of cfg.campos) {
            if (c.ref !== tabelaAlvo) continue;

            if (c.tipo === 'multi') {
                gravar(outraTabela, ler(outraTabela).map(r =>
                    ({ ...r, [c.nome]: (r[c.nome] || []).filter(x => x !== id) })));
            } else if (c.obrigatorio) {
                ler(outraTabela).filter(r => r[c.nome] === id)
                                .forEach(r => excluir(outraTabela, r.id));   // CASCADE
            } else {
                gravar(outraTabela, ler(outraTabela).map(r =>
                    r[c.nome] === id ? { ...r, [c.nome]: null } : r));       // SET NULL
            }
        }
    }
}

// ---------- Mensagenzinha de feedback ----------
function mostrar(texto) {
    msg.textContent = texto;
    setTimeout(() => msg.textContent = '', 2500);
}

// ---------- Começa ----------
montarFormulario();
desenharTabela();
