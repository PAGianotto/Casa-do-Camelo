// =====================================================================
// entidades.js  -  A "planta" de todas as telas de cadastro.
//
// Cada entidade = uma TABELA do banco de dados (ver banco_atualizado.sql).
// Cada "campo" = uma COLUNA da tabela = um <input> no formulário.
//
// tipos de campo:
//   text / url / number / date / textarea -> campos normais
//   select -> lista suspensa que escolhe UM registro de outra tabela (chave estrangeira, 1:N)
//   multi  -> lista que permite escolher VÁRIOS registros de outra tabela (tabela associativa, N:M)
//
// Para criar uma tela nova, basta adicionar uma entidade aqui.
// =====================================================================

const ENTIDADES = {

  // ---- tabela Genre ----
  genre: {
    titulo: 'Gêneros',
    campos: [
      { nome: 'nome', rotulo: 'Nome do gênero', tipo: 'text', obrigatorio: true, dica: 'ex. RPG' }
    ]
  },

  // ---- tabela Plataform ----
  plataforma: {
    titulo: 'Plataformas',
    campos: [
      { nome: 'nome',       rotulo: 'Nome da plataforma', tipo: 'text', obrigatorio: true, dica: 'ex. Game Boy Advance' },
      { nome: 'fabricante', rotulo: 'Fabricante',         tipo: 'text', dica: 'ex. Nintendo' }
    ]
  },

  // ---- tabela Director ----
  director: {
    titulo: 'Diretores',
    campos: [
      { nome: 'nome', rotulo: 'Nome do diretor', tipo: 'text', obrigatorio: true, dica: 'ex. Satoshi Tajiri' }
    ]
  },

  // ---- tabela Publisher  (+ tabela associativa Publisher_Director) ----
  publisher: {
    titulo: 'Publicadoras',
    campos: [
      { nome: 'nome',          rotulo: 'Nome da publicadora', tipo: 'text',   obrigatorio: true, dica: 'ex. Nintendo' },
      { nome: 'pais',          rotulo: 'País',                tipo: 'text' },
      { nome: 'ano_fundacao',  rotulo: 'Ano de fundação',     tipo: 'number', dica: 'ex. 1889' },
      { nome: 'site',          rotulo: 'Site oficial',        tipo: 'url',    dica: 'https://...' },
      { nome: 'diretores',     rotulo: 'Diretores (segure Ctrl para escolher vários)', tipo: 'multi', ref: 'director' }
    ]
  },

  // ---- tabela Nome_Game  (+ tabela associativa Game_Genre) ----
  game: {
    titulo: 'Jogos',
    campos: [
      { nome: 'nome',            rotulo: 'Nome do jogo',     tipo: 'text',     obrigatorio: true, dica: 'ex. Pokémon FireRed' },
      { nome: 'descricao',       rotulo: 'Descrição',        tipo: 'textarea' },
      { nome: 'imagem_url',      rotulo: 'URL da capa',      tipo: 'url',      dica: 'https://...' },
      { nome: 'data_lancamento', rotulo: 'Data de lançamento', tipo: 'date' },
      { nome: 'id_publisher',    rotulo: 'Publicadora',      tipo: 'select',   ref: 'publisher' },
      { nome: 'generos',         rotulo: 'Gêneros (segure Ctrl para escolher vários)', tipo: 'multi', ref: 'genre' }
    ]
  },

  // ---- tabela Rom_Hack ----
  rom_hack: {
    titulo: 'Rom Hacks',
    campos: [
      { nome: 'nome',      rotulo: 'Nome do rom hack', tipo: 'text', obrigatorio: true, dica: 'ex. Pokémon Radical Red' },
      { nome: 'descricao', rotulo: 'Descrição',        tipo: 'textarea' },
      { nome: 'autor',     rotulo: 'Autor do hack',    tipo: 'text' },
      { nome: 'versao',    rotulo: 'Versão',           tipo: 'text', dica: 'ex. 4.1' },
      { nome: 'id_game',   rotulo: 'Jogo base',        tipo: 'select', ref: 'game' }
    ]
  },

  // ---- tabela Arquivo_Game ----
  arquivo_game: {
    titulo: 'Arquivos de Jogos',
    exibir: 'url_download',
    campos: [
      { nome: 'id_game',       rotulo: 'Jogo',              tipo: 'select', ref: 'game',       obrigatorio: true },
      { nome: 'id_plataforma', rotulo: 'Plataforma',        tipo: 'select', ref: 'plataforma', obrigatorio: true },
      { nome: 'url_download',  rotulo: 'URL de download',   tipo: 'url',    obrigatorio: true, dica: 'https://...' },
      { nome: 'tamanho_bytes', rotulo: 'Tamanho (bytes)',   tipo: 'number' },
      { nome: 'formato',       rotulo: 'Formato',           tipo: 'text',   dica: 'ex. .gba' },
      { nome: 'hash_md5',      rotulo: 'Hash MD5 (32 caracteres)',  tipo: 'text', max: 32 },
      { nome: 'hash_sha1',     rotulo: 'Hash SHA1 (40 caracteres)', tipo: 'text', max: 40 },
      { nome: 'idioma',        rotulo: 'Idioma',            tipo: 'text',   max: 20, dica: 'ex. Português' }
    ]
  },

  // ---- tabela Arquivo_Rom_Hack ----
  arquivo_rom_hack: {
    titulo: 'Arquivos de Rom Hacks',
    exibir: 'url_download',
    campos: [
      { nome: 'id_rom_hack',   rotulo: 'Rom Hack',          tipo: 'select', ref: 'rom_hack',   obrigatorio: true },
      { nome: 'id_plataforma', rotulo: 'Plataforma',        tipo: 'select', ref: 'plataforma', obrigatorio: true },
      { nome: 'url_download',  rotulo: 'URL de download',   tipo: 'url',    obrigatorio: true, dica: 'https://...' },
      { nome: 'tamanho_bytes', rotulo: 'Tamanho (bytes)',   tipo: 'number' },
      { nome: 'formato',       rotulo: 'Formato',           tipo: 'text',   dica: 'ex. .gba' },
      { nome: 'hash_md5',      rotulo: 'Hash MD5 (32 caracteres)',  tipo: 'text', max: 32 },
      { nome: 'hash_sha1',     rotulo: 'Hash SHA1 (40 caracteres)', tipo: 'text', max: 40 },
      { nome: 'idioma',        rotulo: 'Idioma',            tipo: 'text',   max: 20 }
    ]
  }
};
