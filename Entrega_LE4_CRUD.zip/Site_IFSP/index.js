const express = require('express');
const app = express();
app.listen(3000, () => console.log("escutando na porta 3000"));

app.use(express.static('top'));

