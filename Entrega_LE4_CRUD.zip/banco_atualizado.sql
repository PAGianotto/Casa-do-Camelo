-- =====================================================================
-- banco_atualizado.sql  -  Banco completo, já com as correções do grupo
-- (Director/Publisher_Director, Game_Genre, Arquivo_Game, Arquivo_Rom_Hack)
-- e com as colunas necessárias para cada formulário web.
--
-- ATENÇÃO: o arquivo "novobanco.sql" original só tinha as tabelas NOVAS e
-- apontava para tabelas que não estavam nele (Publisher, Nome_Game, Genre,
-- Plataform, Rom_Hack). Abaixo elas foram recriadas pelos campos dos
-- formulários. Se o seu banco antigo tiver colunas diferentes, ajuste aqui.
-- =====================================================================

CREATE DATABASE IF NOT EXISTS casa_do_camelo CHARACTER SET utf8mb4;
USE casa_do_camelo;

-- ---------- Tabelas básicas (sem chave estrangeira) ----------
CREATE TABLE IF NOT EXISTS Genre (
    id_genre INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS Plataform (
    id_plataforma INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    fabricante VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS Director (
    id_director INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL
);

-- Publisher: a coluna multivalorada de diretores (se existia) foi REMOVIDA
-- e virou a tabela Publisher_Director (relação N:M).
-- Se o seu banco antigo ainda tem essa coluna, rode:
--   ALTER TABLE Publisher DROP COLUMN diretores;   -- (use o nome real da coluna)
CREATE TABLE IF NOT EXISTS Publisher (
    id_publisher INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    pais VARCHAR(60),
    ano_fundacao INT,
    site VARCHAR(255)
);

-- ---------- Tabelas que dependem das de cima ----------
CREATE TABLE IF NOT EXISTS Nome_Game (
    id_game INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    descricao TEXT,
    imagem_url VARCHAR(255),
    data_lancamento DATE,
    id_publisher INT NULL,
    FOREIGN KEY (id_publisher) REFERENCES Publisher(id_publisher) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS Rom_Hack (
    id_rom_hack INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    descricao TEXT,
    autor VARCHAR(100),
    versao VARCHAR(20),
    id_game INT NULL,                       -- jogo original em que o hack se baseia
    FOREIGN KEY (id_game) REFERENCES Nome_Game(id_game) ON DELETE SET NULL
);

-- ---------- Parte nova do grupo (igual ao novobanco.sql) ----------
-- 1. Remoção do campo multivalorado de Publisher
CREATE TABLE IF NOT EXISTS Publisher_Director (
    id_publisher INT NOT NULL,
    id_director INT NOT NULL,
    PRIMARY KEY (id_publisher, id_director),
    FOREIGN KEY (id_publisher) REFERENCES Publisher(id_publisher) ON DELETE CASCADE,
    FOREIGN KEY (id_director) REFERENCES Director(id_director) ON DELETE CASCADE
);

-- 2. Tabela associativa N:M entre Jogos e Géneros
CREATE TABLE IF NOT EXISTS Game_Genre (
    id_game INT NOT NULL,
    id_genre INT NOT NULL,
    PRIMARY KEY (id_game, id_genre),
    FOREIGN KEY (id_game) REFERENCES Nome_Game(id_game) ON DELETE CASCADE,
    FOREIGN KEY (id_genre) REFERENCES Genre(id_genre) ON DELETE CASCADE
);

-- 3. Separação de ficheiros (3FN)
CREATE TABLE IF NOT EXISTS Arquivo_Game (
    id_arquivo INT AUTO_INCREMENT PRIMARY KEY,
    id_game INT NOT NULL,
    id_plataforma INT NOT NULL,
    url_download VARCHAR(255) NOT NULL,
    tamanho_bytes BIGINT,
    formato VARCHAR(20),
    hash_md5 VARCHAR(32),
    hash_sha1 VARCHAR(40),
    idioma VARCHAR(20),
    FOREIGN KEY (id_game) REFERENCES Nome_Game(id_game) ON DELETE CASCADE,
    FOREIGN KEY (id_plataforma) REFERENCES Plataform(id_plataforma) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS Arquivo_Rom_Hack (
    id_arquivo INT AUTO_INCREMENT PRIMARY KEY,
    id_rom_hack INT NOT NULL,
    id_plataforma INT NOT NULL,
    url_download VARCHAR(255) NOT NULL,
    tamanho_bytes BIGINT,
    formato VARCHAR(20),
    hash_md5 VARCHAR(32),
    hash_sha1 VARCHAR(40),
    idioma VARCHAR(20),
    FOREIGN KEY (id_rom_hack) REFERENCES Rom_Hack(id_rom_hack) ON DELETE CASCADE,
    FOREIGN KEY (id_plataforma) REFERENCES Plataform(id_plataforma) ON DELETE CASCADE
);
