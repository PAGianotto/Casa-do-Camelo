# Guia para humanos das cavernas (sem pânico)

## 0. Como rodar (2 minutos)
1. Abra a pasta `Site_IFSP` no terminal.
2. `npm install` (só na primeira vez) e depois `node index.js`.
3. Abra no navegador: **http://localhost:3000/cadastro_game.html**
4. O menu roxo no topo leva às outras 7 telas.

Ordem recomendada para testar: Gêneros → Diretores → Publicadoras → Plataformas → Jogos → Rom Hacks → Arquivos.
(Telas de baixo escolhem itens das de cima, igual chave estrangeira no banco.)

## 1. O que é "CRUD"?
Quatro verbos que todo cadastro precisa:
- **C**reate: criar → botão *Salvar*
- **R**ead: ler → a tabela embaixo do formulário
- **U**pdate: editar → botão *Editar* (joga os dados no formulário; vira *Atualizar*)
- **D**elete: excluir → botão *Excluir*

## 2. Entidade, atributo, tabela
- **Entidade** = uma "coisa" do mundo (Jogo, Publicadora...). Vira uma **tabela**.
- **Atributo** = característica da coisa (nome, país...). Vira uma **coluna** e um **campo do formulário**.
- Revisar "se os atributos atendem ao formulário" = conferir que cada coluna tem um campo e vice-versa.
  O resultado está no `Atividade_Revisao_CRUD.docx`.

## 3. Relações (o que o SQL do grupo faz)
| Tipo | Exemplo | Como aparece |
|---|---|---|
| 1:N | Uma Publicadora tem vários Jogos | coluna `id_publisher` dentro de `Nome_Game` (**FK**) → no site, lista suspensa |
| N:M | Um Jogo tem vários Gêneros, um Gênero está em vários Jogos | tabela do meio `Game_Genre` → no site, lista de seleção múltipla (Ctrl) |

Por que o `novobanco.sql` criou `Publisher_Director`? Porque "vários diretores numa célula" (campo multivalorado) é proibido em banco bem feito; a solução é uma tabela do meio.
Por que `Arquivo_Game`? Para o arquivo (url, hash, formato...) não ficar misturado na tabela do jogo (3ª forma normal).

`ON DELETE CASCADE` = apagou o pai, apaga os filhos. `ON DELETE SET NULL` = apagou o pai, o filho fica sem pai.

## 4. Os arquivos novos (todos em `Site_IFSP/top/`)
| Arquivo | Papel |
|---|---|
| `cadastro_*.html` (8) | Páginas quase idênticas. A única diferença é `<body data-entidade="game">`. |
| `entidades.js` | **A planta**: lista de tabelas e campos. Quer um campo novo? Adicione uma linha aqui. |
| `crud.js` | **O motor**: lê a planta, desenha formulário e tabela, salva, edita, exclui. |
| `cadastro.css` | Cores roxas e layout. |

### Como o `crud.js` funciona, por partes
1. **`ler()` / `gravar()`** – falam com o `localStorage` (a "gavetinha" do navegador, que só guarda texto; por isso `JSON.stringify` para guardar e `JSON.parse` para ler). Cada tabela é a chave `db_game`, `db_genre`...
2. **`montarFormulario()`** – percorre os campos da planta e cria `<input>`, `<textarea>` ou `<select>` conforme o `tipo`.
3. **`submit`** – ao clicar Salvar: `preventDefault()` (impede a página de recarregar), lê os campos e então:
   - se `editandoId` é `null` → cria com novo id (maior id + 1, imitando `AUTO_INCREMENT`);
   - senão → substitui o registro existente.
4. **`desenharTabela()`** – monta o `<table>`. Ids de chave estrangeira são trocados pelo nome (`rotulo()`: 3 → "Nintendo").
5. **`editar(id)`** – copia o registro para o formulário.
6. **`excluir()`** – apaga e imita o SQL: ligação obrigatória → apaga filhos (CASCADE); opcional → vira vazio (SET NULL); lista N:M → só remove o id.
7. **`esc()`** – converte `<` e `>` para não executar código digitado nos campos (segurança).

## 5. Os erros do `form.html` antigo (por isso foi refeito)
- Campo "Descrição" era `type="url"` recebendo link de imagem.
- O `<textarea id="paragrafo">` nunca era salvo.
- O botão "fundo preto" ficava dentro do form sem `type="button"`, então enviava o formulário.
- Não havia campo para publicadora, gêneros, plataforma, arquivo...
Nada foi apagado: o `form.html` antigo continua lá.

## 6. Limitações honestas
- Os dados ficam no **navegador** (localStorage), não no MySQL. O SQL é a modelagem do banco; para gravar de verdade nele é preciso um backend (Express + `mysql2`). É o passo seguinte natural.
- O `novobanco.sql` não trazia as tabelas `Publisher`, `Nome_Game`, `Genre`, `Plataform`, `Rom_Hack`. Recriei por dedução dos formulários em `banco_atualizado.sql`. **Compare com o seu banco antigo** e ajuste nomes de colunas se divergirem.
- O enunciado só detalha o item 1; o item 2 ficou como espaço em branco no .docx.
