class ObraDeArte{
    constructor(titulo, descricao, imagem){
        this.titulo = titulo;
        this.descricao = descricao;
        this.imagem = imagem;
    }
}

const formulario = document.getElementById('meuFormulario');
const colecao = document.getElementById('colecao');

formulario.addEventListener('submit', function(evento) {
    evento.preventDefault();
    const tituloF = document.getElementById('titulo').value;
    const paragrafoF = document.getElementById('paragrafo').value;
    const imagemF = document.getElementById('imagem').value;
    
    const novaObra = new ObraDeArte(tituloF, paragrafoF, imagemF);
    console.log(novaObra);
    console.log(JSON.stringify(novaObra));
    fetch('/api/lista', {
        method: 'POST',
        headers: {
            'Content-Type': 'aplication/json'
        },
        body: JSON.stringify(novaObra)
    })
    .then(reposta => reposta.json())
    .then(() => {
        alert('Obra enviada com sucesso!')
        formulario.reset();
        // window.location.href = 'index.html';
    })
    .catch(erro => console.error('Erro ao enviar', erro));
})
