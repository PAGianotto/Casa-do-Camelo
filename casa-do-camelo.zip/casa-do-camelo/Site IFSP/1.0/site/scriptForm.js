// Formulário que CRIA ou EDITA um card de jogo.
// form.html          -> cria um novo
// form.html?id=3     -> edita o jogo 3
// (criarCard() vem do scriptindex.js)

const formulario = document.getElementById('meuFormulario');
const previa = document.getElementById('previa');
const btnExcluir = document.getElementById('btnExcluir');
const idEditando = new URLSearchParams(location.search).get('id');

const campos = ['titulo', 'tipo', 'plataforma', 'imagem', 'descricao', 'link'];

// Lê o que está digitado no formulário
function lerFormulario() {
    const jogo = {};
    campos.forEach(campo => {
        jogo[campo] = document.getElementById(campo).value;
    });
    return jogo;
}

// Redesenha a prévia do card a cada tecla
function atualizarPrevia() {
    previa.innerHTML = criarCard(lerFormulario());
}

formulario.addEventListener('input', atualizarPrevia);
atualizarPrevia();

// Se veio ?id= na URL, carrega o jogo para editar
if (idEditando) {
    document.getElementById('tituloForm').textContent = 'Editar jogo';
    document.getElementById('btnSalvar').textContent = 'Salvar alterações';
    btnExcluir.hidden = false;

    fetch('/api/jogos/' + idEditando)
        .then(resposta => resposta.json())
        .then(jogo => {
            campos.forEach(campo => {
                document.getElementById(campo).value = jogo[campo] || '';
            });
            atualizarPrevia();
        })
        .catch(erro => console.error('Erro ao carregar o jogo', erro));
}

// Salvar (cria ou edita)
formulario.addEventListener('submit', function (evento) {
    evento.preventDefault();

    const url = idEditando ? '/api/jogos/' + idEditando : '/api/jogos';
    const metodo = idEditando ? 'PUT' : 'POST';

    fetch(url, {
        method: metodo,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(lerFormulario())
    })
        .then(resposta => {
            if (!resposta.ok) throw new Error('Erro ' + resposta.status);
            return resposta.json();
        })
        .then(jogo => {
            window.location.href = 'card.html?id=' + jogo.id;
        })
        .catch(erro => {
            console.error('Erro ao salvar', erro);
            alert('Não foi possível salvar. Veja o console.');
        });
});

// Excluir
btnExcluir.addEventListener('click', function () {
    if (!confirm('Excluir este jogo?')) return;

    fetch('/api/jogos/' + idEditando, { method: 'DELETE' })
        .then(() => {
            window.location.href = 'index.html';
        })
        .catch(erro => console.error('Erro ao excluir', erro));
});
