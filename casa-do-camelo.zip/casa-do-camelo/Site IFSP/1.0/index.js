const express = require('express');
const app = express();
const mysql67 = require('mysql2');

// Lê o JSON que o formulário manda
app.use(express.json());

// Serve os arquivos da pasta 'site' (HTML, CSS, JS, imagens)
app.use(express.static('site'));

const db = mysql67.createConnection({
    host:'localhost',
    user: 'root',
    password:'ifsp',
    database: 'casa_do_camelo'
})

db.connect((erro) =>{
    if(erro){
        console.error(':(', erro);
    }
    else{
        console.log('conectado ao banco!')
    }
});

// "Banco" temporário na memória (some quando o servidor reinicia)
let proximoId = 3;
// let jogos = [
//     {
//         id: 1,
//         titulo: 'Pokémon FireRed',
//         tipo: 'ROM',
//         plataforma: 'GBA',
//         imagem: 'https://m.media-amazon.com/images/I/71iLh5opvHL.jpg',
//         descricao: 'Remake dos jogos originais de Game Boy (Red/Blue), ambientado na região de Kanto. Complete a Pokédex, derrote os oito líderes de ginásio e enfrente a Team Rocket.',
//         link: ''
//     },
//     {
//         id: 2,
//         titulo: 'Exemplo de Mod',
//         tipo: 'Mod',
//         plataforma: 'PC',
//         imagem: '',
//         descricao: 'Card de exemplo. Edite ou exclua pelo formulário.',
//         link: ''
//     }
// ];

// Pega só os campos que interessam (evita salvar lixo)
function limpar(dados) {
    return {
        titulo: String(dados.titulo || '').trim(),
        tipo: String(dados.tipo || 'Repack'),
        plataforma: String(dados.plataforma || '').trim(),
        imagem: String(dados.imagem || '').trim(),
        descricao: String(dados.descricao || '').trim(),
        link: String(dados.link || '').trim()
    };
}

// LISTAR todos
app.get('/api/jogos', (req, res) => {
    db.query('SELECT * FROM nome_game', (erro, resultaddo)=>{
        if(erro){
            console.error('erro pra recuperar baguios', erro);
            return res.status(500).json({erro: 'erro ao buscar dados'});
        }
    });
    res.json(jogos);
});

// PEGAR um pelo id
app.get('/api/jogos/:id', (req, res) => {
    const jogo = jogos.find(j => j.id === Number(req.params.id));
    if (!jogo) return res.status(404).json({ erro: 'Jogo não encontrado' });
    res.json(jogo);
});

// CRIAR
app.post('/api/jogos', (req, res) => {
    const novo = { id: proximoId++, ...limpar(req.body) };
    if (!novo.titulo) return res.status(400).json({ erro: 'Título é obrigatório' });
    jogos.push(novo);
    res.status(201).json(novo);
});

// EDITAR
app.put('/api/jogos/:id', (req, res) => {
    const i = jogos.findIndex(j => j.id === Number(req.params.id));
    if (i === -1) return res.status(404).json({ erro: 'Jogo não encontrado' });
    jogos[i] = { id: jogos[i].id, ...limpar(req.body) };
    res.json(jogos[i]);
});

// EXCLUIR
app.delete('/api/jogos/:id', (req, res) => {
    const antes = jogos.length;
    jogos = jogos.filter(j => j.id !== Number(req.params.id));
    if (jogos.length === antes) return res.status(404).json({ erro: 'Jogo não encontrado' });
    res.json({ status: 'excluido' });
});

app.listen(3000, () => {
    console.log('Servidor rodando em http://localhost:3000');
});
